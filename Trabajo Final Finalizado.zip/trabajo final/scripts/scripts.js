function comprarViaje() {
    window.location.href = "comprar viaje new york.html";
  }
  
function opcion2() {
    window.location.href = "formulariocompranewyork.html"; 
}
function opcion1(){
  window.location.href = "comprarviajenewyorkPayPal.html"; 
}
